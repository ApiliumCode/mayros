---
name: zip-hook
description: Zip hook
metadata: {"mayros":{"events":["command:new"]}}
---

# Zip Hook
