---
name: tar-hook
description: tar-hook
metadata: {"mayros":{"events":["command:new"]}}
---

# Hook
