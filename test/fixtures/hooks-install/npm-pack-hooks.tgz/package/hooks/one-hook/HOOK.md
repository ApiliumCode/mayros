---
name: one-hook
description: One hook
metadata: {"mayros":{"events":["command:new"]}}
---

# One Hook
